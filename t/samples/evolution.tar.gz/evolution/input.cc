#include "input.h"

std::string Input::read() {
  return "Hello, world!";
}
