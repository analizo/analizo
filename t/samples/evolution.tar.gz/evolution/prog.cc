#include "input.h"
#include <iostream>
#include "output.h"

int main(int argc, char** argv) {
  if (argc > 1) {
    std::cout << "Usage: " << argv[0] << std::endl;
    return 1;
  }
  Input input;
  std::string data = input.read();
  Output output;
  output.write(data);
  return 0;
}
