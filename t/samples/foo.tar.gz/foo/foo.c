#include <stdio.h>

int main() {
  printf("foo\n");
  return 0;
}
