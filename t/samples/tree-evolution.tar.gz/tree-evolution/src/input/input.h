#ifndef _INPUT_H_
#define _INPUT_H_

#include <string>

class Input {
  public:
    std::string read();
};

#endif // _INPUT_H_
