#ifndef _OUTPUT_H_
#define _OUTPUT_H_

#include <string>

class Output {
  public:
    void write(std::string);
};

#endif // _OUTPUT_H_
