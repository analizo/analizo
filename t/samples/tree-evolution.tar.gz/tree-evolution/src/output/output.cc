#include <iostream>
#include "output.h"

void Output::write(std::string data) {
  std::cout << data << std::endl;
}
